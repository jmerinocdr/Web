<div>
	<div class="formulario">
	<form action="../lib/login.lib.php" method="post">
		<p>Usuario <input type="text" name="user" required=""></p>
		<p>Contraseña <input type="password" name="contrasena" required=""></p>
		<input class="boton"  type="submit" name="Enviar">
	</form>
	</div>
</div>