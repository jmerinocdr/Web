<?php include_once('../HeaderFooter/Header.php'); ?>
    <h1>Introduce los datos para modificar la persona</h1>
    <div class="formulario">
    <form action="../lib/moddatos.lib.php" method="post" enctype="multipart/form-data">
        <?php include('../lib/moddatos.lib.php'); ?>
    </form>
	</div>
</body>
</html>