<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <h1>Introduce los datos para modificar la persona</h1>
    <form action="../lib/moddatos.lib.php" method="post" enctype="multipart/form-data">
        <?php include('../lib/moddatos.lib.php'); ?>
    </form>
</body>
</html>