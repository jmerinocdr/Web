<div>
	<div class="formulario">
		<form action="../lib/registro.lib.php" method="post">
			<p>Nombre <input type="text" name="usuario" required=""></p>
			<p>Contraseña <input type="password" name="clave" required=""></p>
			<p>Verificar Contraseña <input type="password" name="pclave" required=""></p>
			<input  class="boton"  type="submit" name="Enviar">
		</form>
	</div>
</div>