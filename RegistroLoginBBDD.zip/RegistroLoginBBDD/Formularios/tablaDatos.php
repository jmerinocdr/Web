<table>
	<tr>
		<td><p>Id</p></td>
		<td><p>Nombre</p> </td>
		<td><p>Nacimiento</p></td>
		<td><p>Sexo</p></td>
		<td><p>Deporte</p></td>
		<td><p>Foto</p></td>
	</tr>
	<?php
	include_once('../lib/listardatos.lib.php');
echo "</table>";