
<div>
	<a href="php/login.php">Login</a>
	<a href="php/registro.php">Registro</a>
</div>