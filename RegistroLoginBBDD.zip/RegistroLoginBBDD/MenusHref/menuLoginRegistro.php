
<div>
	<br/>
	<br/>
	<a class="boton" href="../php/login.php">Login</a>
	<a  class="boton" href="../php/registro.php">Registro</a>
</div>