
<div>
	<a  class="boton" href="../Formularios/formAdd.php">Añadir</a>
	<a  class="boton" href="../lib/salir.lib.php">Salir</a>
</div>