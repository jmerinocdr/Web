
<div>
	<a href="Formularios/formAdd.php">Añadir</a>
	<a href="lib/salir.lib.php">Salir</a>
</div>