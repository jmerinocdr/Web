<?php
	require_once('../config/config.php');
	require_once('dao.php');
	require_once('checkSession.lib.php');