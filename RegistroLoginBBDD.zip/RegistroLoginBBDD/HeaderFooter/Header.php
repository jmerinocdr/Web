<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>RegistroLogin</title>
	<link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
</head>
<body>
	<header>Registro Login</header>
	<br>
