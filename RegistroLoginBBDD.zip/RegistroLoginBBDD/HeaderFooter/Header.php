<!DOCTYPE html>
<html>
<head>
	<title>RegistroLogin</title>
</head>
<body>
	<link rel="stylesheet" href="../css/stylesheet.css">
	<header>Registro Login</header>
