<?php
	header('Location: php/Index.php');