<?php
	require_once('HeaderFooter/Header.php');
	require_once('MenusHref/menuLoginRegistro.php');
	require_once('HeaderFooter/Footer.php');