<?php
	//Información necesaria para trabajar con la base de datos
	define('SERVICE', 'mysql');
	define('USER', 'root');
	define('PASS', '');
	define('HOST', 'localhost');
	define('DBNAME', 'usuarios');
	//
	//Información del directorio donde se guardan las imagenes
	define('DIRECTORIO', '../img/');