<?php
	require_once('../lib/lib.php');
	include_once('../HeaderFooter/Header.php');
	include_once('../Formularios/formLogin.php');
	include_once('../HeaderFooter/Footer.php');