<?php
	require_once('../lib/lib.php');
	include_once('../HeaderFooter/Header.php');
	include_once('../Formularios/tablaDatos.php');
	include_once('../MenusHref/menuAddExit.php');
	include_once('../HeaderFooter/Footer.php');