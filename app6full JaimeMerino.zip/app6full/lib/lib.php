<?php
require_once('config.php');

// Incluyo todas la librerías necesarias
require_once('session.lib.php');
require_once('form.lib.php');
require_once('app.lib.php');

require_once('usuario.dao.php');
require_once('deporte.dao.php');
