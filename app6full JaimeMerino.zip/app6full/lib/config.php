<?php
define('FIC_DATOS', '../data/datos.sqlite');
define('DIR_FOTOS', '../data/fotos/');

// Errores de la aplicación
define('LST_ERRORES', [
        'login' => 'Acceso no autorizado'
    ]
);
