<?php
    require_once('../lib/lib.php');
    sessionDestroy();

    include_once('../inc/header.php');
    include_once("../tpl/login.php");
    include_once('../inc/footer.php');
