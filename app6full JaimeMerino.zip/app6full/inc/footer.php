    <hr>
    <footer>
        <p>Amadeo Mora / copyleft / 2020</p>
    </footer>
    </body>
</html>